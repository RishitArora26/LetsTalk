Created a multiuser Realtime Chat Web Application Using NodeJs and SocketIO.
• Used SocketIO for realtime communication. HTML, CSS, JavaScript for frontend and NodeJS for writing
backend.
• Tested that the backend works, by handling more than 40 members in a single room with a seamless
experience.
